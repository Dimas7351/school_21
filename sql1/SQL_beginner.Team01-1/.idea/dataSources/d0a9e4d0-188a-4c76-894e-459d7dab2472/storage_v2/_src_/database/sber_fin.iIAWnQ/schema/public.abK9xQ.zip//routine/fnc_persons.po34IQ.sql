create function fnc_persons(pgender character varying DEFAULT 'female'::character varying)
    returns TABLE(id bigint, name character varying, age integer, gender character varying, address character varying)
    language sql
as
$$
select * from person
where gender = pgender
$$;

alter function fnc_persons(varchar) owner to postgres;

