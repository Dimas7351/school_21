create function fnc_fibonacci(pstop integer DEFAULT 10)
    returns TABLE(num integer)
    language sql
as
$$
with recursive cte_fib(n1, n2) as
    (values (0,1)
        union all
        select n2, n1+n2
        from cte_fib where n2<pstop)
    select n1 from cte_fib;
$$;

alter function fnc_fibonacci(integer) owner to postgres;

