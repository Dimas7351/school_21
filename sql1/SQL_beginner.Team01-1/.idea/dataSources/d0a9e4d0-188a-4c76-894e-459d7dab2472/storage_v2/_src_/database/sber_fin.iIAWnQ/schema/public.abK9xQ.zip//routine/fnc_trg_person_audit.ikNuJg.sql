create function fnc_trg_person_audit() returns trigger
    language plpgsql
as
$$
begin
    if (TG_OP = 'INSERT') then
        insert into person_audit(type_event, row_id, name, age, gender, address)
        values ('I', new.id, new.name, new.age, new.gender, new.address);
    elseif (TG_OP = 'UPDATE') then
        insert into person_audit(type_event, row_id, name, age, gender, address)
        values ('U', old.id, old.name, old.age, old.gender, old.address);
    else
        insert into person_audit(type_event, row_id, name, age, gender, address)
        values ('D', old.id, old.name, old.age, old.gender, old.address);
        end if;
    return null;
end;
$$;

alter function fnc_trg_person_audit() owner to postgres;

